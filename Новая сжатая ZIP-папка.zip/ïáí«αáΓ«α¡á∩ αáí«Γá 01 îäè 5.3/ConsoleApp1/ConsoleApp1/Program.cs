﻿using System;

namespace ConsoleApp1
{
    class Program
    {

        static void Main(string[] args)
        {
            Power(2, -3);
        }
        static public double Power(double x, int n)
        {
            double z = 1;
            int i;
            if ((x>=0 && x<=999)||(n>0 && n<=100))
            {
                Console.WriteLine("Ошибка!");
                z = 1;
            }
            else
            {
                for (i = 1; n >= i; i++)
                {
                    z = z * x;
                    Console.WriteLine("i = {0} z = {1}", i, z);
                }
            }
            return z;
        }
    }
}
